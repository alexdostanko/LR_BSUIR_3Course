﻿#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <ctime>
#include <string>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

#pragma pack(push, 1)
struct GETSINCHRO
{
    char cmd[4];
    long long curvalue;
};

struct SETSINCHRO
{
    char cmd[4];
    long long correction;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct NTPPacket
{
    unsigned char li_vn_mode;
    unsigned char stratum;
    unsigned char poll;
    unsigned char precision;

    unsigned int rootDelay;
    unsigned int rootDispersion;
    unsigned int refId;

    unsigned int refTimeSec;
    unsigned int refTimeFrac;

    unsigned int origTimeSec;
    unsigned int origTimeFrac;

    unsigned int recvTimeSec;
    unsigned int recvTimeFrac;

    unsigned int txTimeSec;
    unsigned int txTimeFrac;
};
#pragma pack(pop)

long long getNTPTimeMs()
{
    SOCKET sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == INVALID_SOCKET)
    {
        return -1;
    }

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(123);

    inet_pton(AF_INET, "129.6.15.28", &serverAddr.sin_addr);

    NTPPacket packet{};
    packet.li_vn_mode = 0x1B;

    int sendRes = sendto(sock, (char*)&packet, sizeof(packet), 0,
        (sockaddr*)&serverAddr, sizeof(serverAddr));

    if (sendRes == SOCKET_ERROR)
    {
        closesocket(sock);
        return -1;
    }

    sockaddr_in from{};
    int fromLen = sizeof(from);

    int recvRes = recvfrom(sock, (char*)&packet, sizeof(packet), 0,
        (sockaddr*)&from, &fromLen);

    if (recvRes == SOCKET_ERROR)
    {
        closesocket(sock);
        return -1;
    }

    closesocket(sock);

    unsigned int seconds = ntohl(packet.txTimeSec);
    unsigned int fraction = ntohl(packet.txTimeFrac);

    const unsigned int seventyYears = 2208988800U;
    unsigned long long unixSeconds = seconds - seventyYears;

    unsigned long long milliseconds = unixSeconds * 1000ULL;
    milliseconds += (unsigned long long)((fraction * 1000.0) / 4294967296.0);

    return (long long)milliseconds;
}

int main()
{
    setlocale(LC_ALL, "Russian");

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        cout << "Ошибка WSAStartup" << endl;
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (serverSocket == INVALID_SOCKET)
    {
        cout << "Ошибка создания сокета: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(54000);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
    {
        cout << "Ошибка bind: " << WSAGetLastError() << endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    cout << "Локальный UDP-сервер времени запущен на порту 54000" << endl;
    cout << "Ожидание запросов клиентов..." << endl;

    int requestNumber = 0;

    while (true)
    {
        sockaddr_in clientAddr{};
        int clientAddrSize = sizeof(clientAddr);

        GETSINCHRO request{};

        int recvLen = recvfrom(
            serverSocket,
            (char*)&request,
            sizeof(request),
            0,
            (sockaddr*)&clientAddr,
            &clientAddrSize
        );

        if (recvLen == SOCKET_ERROR)
        {
            cout << "Ошибка recvfrom: " << WSAGetLastError() << endl;
            continue;
        }

        if (strncmp(request.cmd, "SYNC", 4) != 0)
        {
            cout << "Неизвестная команда" << endl;
            continue;
        }

        long long Cs = getNTPTimeMs();
        if (Cs == -1)
        {
            cout << "Не удалось получить время с NTP-сервера" << endl;
            continue;
        }

        long long correction = Cs - request.curvalue;

        SETSINCHRO response{};
        memcpy(response.cmd, "SYNC", 4);
        response.correction = correction;

        int sendLen = sendto(
            serverSocket,
            (char*)&response,
            sizeof(response),
            0,
            (sockaddr*)&clientAddr,
            clientAddrSize
        );

        if (sendLen == SOCKET_ERROR)
        {
            cout << "Ошибка sendto: " << WSAGetLastError() << endl;
            continue;
        }

        requestNumber++;

        char clientIp[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &(clientAddr.sin_addr), clientIp, INET_ADDRSTRLEN);

        cout << "Клиент: " << clientIp
            << " | запрос #" << requestNumber
            << " | curvalue = " << request.curvalue
            << " | Cs = " << Cs
            << " | correction = " << correction
            << endl;
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
