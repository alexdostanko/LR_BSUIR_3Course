﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <ctime>
#include <vector>
#include <iomanip>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

#pragma pack(push, 1)
struct GETSINCHRO
{
    char cmd[4];
    int curvalue;
};

struct SETSINCHRO
{
    char cmd[4];
    int correction;
};
#pragma pack(pop)

int main()
{
    setlocale(LC_ALL, "Russian");

    WSADATA wsaData;
    int wsaResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (wsaResult != 0)
    {
        cout << "Ошибка WSAStartup: " << wsaResult << endl;
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (serverSocket == INVALID_SOCKET)
    {
        cout << "Ошибка создания сокета: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(54000);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
    {
        cout << "Ошибка bind: " << WSAGetLastError() << endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    cout << "UDP-сервер запущен на порту 54000" << endl;

    clock_t startClock = clock();
    int requestNumber = 0;
    vector<int> corrections;

    while (true)
    {
        sockaddr_in clientAddr{};
        int clientAddrSize = sizeof(clientAddr);

        GETSINCHRO request{};

        int recvLen = recvfrom(
            serverSocket,
            (char*)&request,
            sizeof(request),
            0,
            (sockaddr*)&clientAddr,
            &clientAddrSize
        );

        if (recvLen == SOCKET_ERROR)
        {
            cout << "Ошибка recvfrom: " << WSAGetLastError() << endl;
            continue;
        }

        if (strncmp(request.cmd, "SYNC", 4) != 0)
        {
            cout << "Получена неизвестная команда" << endl;
            continue;
        }

        int Cs = (int)((clock() - startClock) * 1000 / CLOCKS_PER_SEC);
        int correction = Cs - request.curvalue;

        SETSINCHRO response{};
        memcpy(response.cmd, "SYNC", 4);
        response.correction = correction;

        int sendLen = sendto(
            serverSocket,
            (char*)&response,
            sizeof(response),
            0,
            (sockaddr*)&clientAddr,
            clientAddrSize
        );

        if (sendLen == SOCKET_ERROR)
        {
            cout << "Ошибка sendto: " << WSAGetLastError() << endl;
            continue;
        }

        corrections.push_back(correction);
        requestNumber++;

        char clientIp[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &(clientAddr.sin_addr), clientIp, INET_ADDRSTRLEN);

        double avg = 0;
        for (int x : corrections) avg += x;
        avg /= corrections.size();

        cout << "Клиент: " << clientIp
            << " | запрос #" << requestNumber
            << " | curvalue = " << request.curvalue
            << " | Cs = " << Cs
            << " | correction = " << correction
            << " | avg = " << fixed << setprecision(2) << avg
            << endl;
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
