﻿#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <vector>
#include <iomanip>
#include <windows.h>
#include <ctime>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

#pragma pack(push, 1)
struct GETSINCHRO
{
    char cmd[4];
    long long curvalue;
};

struct SETSINCHRO
{
    char cmd[4];
    long long correction;
};
#pragma pack(pop)

long long getSystemTimeMs()
{
    return (long long)time(nullptr) * 1000LL;
}

int main()
{
    setlocale(LC_ALL, "Russian");

    string serverIp;
    int Tc;

    cout << "Введите IP локального сервера: ";
    cin >> serverIp;

    cout << "Введите Tc в миллисекундах: ";
    cin >> Tc;

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        cout << "Ошибка WSAStartup" << endl;
        return 1;
    }

    SOCKET clientSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (clientSocket == INVALID_SOCKET)
    {
        cout << "Ошибка создания сокета: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(54000);
    inet_pton(AF_INET, serverIp.c_str(), &serverAddr.sin_addr);

    long long curvalue = getSystemTimeMs();
    vector<long long> corrections;

    for (int i = 1; i <= 10; i++)
    {
        Sleep(Tc);

        curvalue += Tc;

        GETSINCHRO request{};
        memcpy(request.cmd, "SYNC", 4);
        request.curvalue = curvalue;

        int sendLen = sendto(
            clientSocket,
            (char*)&request,
            sizeof(request),
            0,
            (sockaddr*)&serverAddr,
            sizeof(serverAddr)
        );

        if (sendLen == SOCKET_ERROR)
        {
            cout << "Ошибка sendto: " << WSAGetLastError() << endl;
            continue;
        }

        SETSINCHRO response{};
        sockaddr_in fromAddr{};
        int fromLen = sizeof(fromAddr);

        int recvLen = recvfrom(
            clientSocket,
            (char*)&response,
            sizeof(response),
            0,
            (sockaddr*)&fromAddr,
            &fromLen
        );

        if (recvLen == SOCKET_ERROR)
        {
            cout << "Ошибка recvfrom: " << WSAGetLastError() << endl;
            continue;
        }

        long long correction = response.correction;
        corrections.push_back(correction);

        curvalue += correction;

        cout << "Запрос #" << i
            << " | correction = " << correction
            << " | новое curvalue = " << curvalue
            << endl;
    }

    if (!corrections.empty())
    {
        long long minCorr = corrections[0];
        long long maxCorr = corrections[0];
        long double avg = 0;

        for (long long x : corrections)
        {
            if (x < minCorr) minCorr = x;
            if (x > maxCorr) maxCorr = x;
            avg += x;
        }
        avg /= corrections.size();

        cout << endl;
        cout << "Результаты эксперимента:" << endl;
        cout << "Tc = " << Tc << endl;
        cout << "Max correction = " << maxCorr << endl;
        cout << "Min correction = " << minCorr << endl;
        cout << "Average correction = " << fixed << setprecision(2) << (double)avg << endl;
    }

    closesocket(clientSocket);
    WSACleanup();
    return 0;
}
